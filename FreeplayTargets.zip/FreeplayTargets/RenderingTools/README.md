# RenderingTools
A collection of rendering tools and objects for BakkesMod CanvasWrapper drawing in Rocket League

*NOTE: This collection has been built over the course of a year while I was learning C++ and linear algebra. Many of the functions contained within this library are very inefficient, or the code style may be inconsistent. As I continue to learn both C++ and linear algebra, I will update these functions to be more accurate and efficient.*

**This is a personal repo and as such it is prone to occasional drastic changes.**

**Sometimes code may not work because it relies on beta features of BakkesMod that are not public. If that is the case, try pulling from previous commits, or wait until BakkesMod receives an update.**